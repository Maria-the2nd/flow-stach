/**
 * Flow Stach Designer Extension Entry Point
 * Initializes the extension and sets up the UI panel
 */
export {};
//# sourceMappingURL=index.d.ts.map