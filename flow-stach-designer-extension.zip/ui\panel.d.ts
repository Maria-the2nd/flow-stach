/**
 * Extension UI Panel
 * Main React component for the extension interface
 */
/**
 * Initialize the extension panel
 */
export declare function initializePanel(): void;
//# sourceMappingURL=panel.d.ts.map