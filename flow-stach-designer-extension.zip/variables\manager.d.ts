/**
 * Variable Manager
 * Creates and manages Webflow variables from token manifests
 */
import type { TokenManifest } from '../types';
/**
 * Ensure variables exist in Webflow from token manifest
 * Returns a map of CSS variable name -> Webflow variable UUID
 */
export declare function ensureVariables(manifest: TokenManifest): Promise<Map<string, string>>;
//# sourceMappingURL=manager.d.ts.map