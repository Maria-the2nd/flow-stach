/**
 * DOM Injector
 * Injects nodes and styles into Webflow Designer
 */
import type { ClipboardPayload, InstallResult } from '../types';
/**
 * Install payload into Webflow Designer
 */
export declare function installPayload(payload: ClipboardPayload, skipClasses: string[]): Promise<InstallResult>;
//# sourceMappingURL=dom.d.ts.map