/**
 * Collision Detector
 * Detects existing classes and variables in the target Webflow site
 */
import type { ClipboardPayload, CollisionReport } from '../types';
/**
 * Detect collisions between payload and existing Webflow site
 */
export declare function detectCollisions(payload: ClipboardPayload): Promise<CollisionReport>;
//# sourceMappingURL=detector.d.ts.map