/**
 * UUID Remapper
 * Remaps CSS variable references to Webflow variable UUIDs
 */
/**
 * Remap variable references in styleLess strings
 * Converts: var(--token-name, fallback) -> var(--uuid-xxx)
 */
export declare function remapVariableReferences(styleLess: string, uuidMap: Map<string, string>): string;
/**
 * Remap all variable references in a style object
 */
export declare function remapStyleVariables(style: {
    styleLess: string;
    variants?: Record<string, {
        styleLess: string;
    }>;
}, uuidMap: Map<string, string>): void;
//# sourceMappingURL=remapper.d.ts.map