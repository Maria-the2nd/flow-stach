/**
 * Collision Dialog Component
 * Shows collision warnings and lets user choose which classes to skip
 */
import type { CollisionReport } from '../types';
interface CollisionDialogProps {
    report: CollisionReport;
    onConfirm: (skipClasses: string[]) => void;
    onCancel: () => void;
}
export declare function CollisionDialog({ report, onConfirm, onCancel }: CollisionDialogProps): import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=CollisionDialog.d.ts.map