/**
 * Clipboard Monitor
 * Monitors clipboard for @webflow/XscpData payloads
 */
export declare class ClipboardMonitor {
    private lastClipboardText;
    private checkInterval;
    private isMonitoring;
    start(): void;
    stop(): void;
    private checkClipboard;
    private parseWebflowPayload;
    private onPayloadDetected;
    isActive(): boolean;
}
//# sourceMappingURL=monitor.d.ts.map